    function CalcularTroco (){

        let  ValorDaCompra = parseFloat(document.getElementById('ValorDaCompra').value);
        let  ValorRecebido = parseFloat(document.getElementById('ValorRecebido').value);

        let resultado = ValorRecebido - ValorDaCompra
        
        document.getElementById('ValorDoTroco').innerText = "Valor Do Troco: " + resultado.toFixed(2);
    }